/*
 * DigitalControl.c
 *
 *  Created on: Sep 4, 2024
 *      Author: LDSC
 */
#include "DigitalControl.h"

float angle = 0.0;       // Unit: rad
float velocity = 0.0;    // Unit: rad/s
float voltage = 0.0;	 // Unit: voltage

void control_loop_100hz() {
    angle = getAngle();
    velocity = calculateVelocity();
    printf("%f,%f\r\n", voltage, velocity);
}

float getAngle() {
    static int counter = 0;
    counter = __HAL_TIM_GET_COUNTER(&htim2);
    return (float)(counter / (48.0 * RR) * 2 * M_PI);
}

float calculateVelocity() {
//	**TODO**
//	return the velocity you calculate
	return 0.0;
}

void setMotorVoltage(char* motor, float voltage) {
    // Mapping voltage from [-12, 12]V to duty cycle [0, 100]%
    float duty_cycle = (voltage + 12) / 24 * 100;

    if (strcmp(motor, "motor1") == 0) {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_1, duty_cycle); // Set Pulse
    }
    else if (strcmp(motor, "motor2") == 0) {
        __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_2, duty_cycle);
    }
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
    if (htim == &htim3) {
        control_loop_100hz();
    }
}
