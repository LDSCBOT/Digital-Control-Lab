/*
 * DigitalControl.h
 *
 *  Created on: Sep 4, 2024
 *      Author: LDSC
 */

#ifndef INC_DIGITALCONTROL_H_
#define INC_DIGITALCONTROL_H_

#include <stdio.h>
#include "main.h"
#include "string.h"

extern float angle;    // Unit: rad
extern float velocity; // Unit: rad/s
extern float voltage;  // Unit: voltage

#define M_PI 3.14159265358979323846
/**
 * @brief Define the reduction ratio of the motor you get.
 * @example 30, 90
 */
#define RR 30

/**
 * @brief Executes the main control loop at 100Hz.
 *
 * This function is called periodically to manage the control logic
 * of the system. It typically handles tasks such as reading sensor
 * data, computing control commands, and updating actuators.
 */
void control_loop_100hz();

/**
 * @brief Retrieves the current angle from the encoder. Unit:rad
 *
 * This function reads the encoder data and calculates the
 * current angular position.
 */
float getAngle();

/**
 * @brief Calculates the velocity(after gearbox) based on the current angle. Unit:rad/s
 *
 */
float calculateVelocity();

/**
 * @brief Sets the motor voltage through PWM.
 * @arg[in] motor: The motor to control.
 * @arg[in] voltage: The voltage to apply.
 * @example setMotorVoltage("motor1", 5.0);
 */
void setMotorVoltage(char* motor, float voltage);

// Other functions and variables
extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;

#endif /* INC_DIGITALCONTROL_H_ */
